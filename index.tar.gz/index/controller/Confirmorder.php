<?php
namespace app\index\controller;
use think\Controller;
class Confirmorder extends Controller
{
 public function confirmorder(){
$order1 = array 
(
    "customer_name"=>"张三",
    "customer_phone"=>"12345678900",
    "customer_address"=>"河南省南阳市宛城区枣林街道长江路80号南阳理工学院",
    "customer_service"=>"送货上门"
);

$goods=array(
    0=>array(
        "order2_id"=>"0",
        "goodsId"=>"123456",
        "goodsImg"=>"",
        "goodsName"=>"轻奢衣柜简约现代经济型",
        "orderTransport"=>"3",
        "goodsDetails"=>"单功能柜 单门 不组装",
        "goodsNum"=>"1",
        "price"=>"1999.99"
    ),
    1=>array(  
        "order2_id"=>"0",
        "goodsId"=>"123457",
        "goodsImg"=>"",
        "goodsName"=>"北欧现代简约实木衣柜 2门4门简易小户型",
        "orderTransport"=>"9.9",
        "goodsDetails"=>"衣柜2门；组装",
        "goodsNum"=>"1",
        "price"=>"2999.00"
    ),
    2=>array(  
        "order2_id"=>"1",
        "goodsId"=>"123458",
        "goodsImg"=>"",
        "goodsName"=>"轻奢衣柜简约现代经济型",
        "orderTransport"=>"3",
        "goodsDetails"=>"单功能柜 单门 不组装",
        "goodsNum"=>"1",
        "price"=>"2999.00"
    ), 
    3=>array(            
        "order2_id"=>"1",  
        "goodsId"=>"123459",
        "goodsImg"=>"",
        "goodsName"=>"轻奢衣柜简约现代经济型",
        "orderTransport"=>"3",
        "goodsDetails"=>"颜色分类：单功能柜；门数量:单门；是否组装:否",
        "goodsNum"=>"1",
        "price"=>"2999.00"
    )
);

    $order2 = array
   (
       0=>array( 
           "shopId"=>"1",
           "shopName"=>"家装",
           "logo"=>"",
           "orderWay"=>"送货上门"
       ),
       1=>array(     
           "shopId"=>"100002",
           "shopName"=>"家装",
           "logo"=>"",
           "orderWay"=>"送货上门"           
       )
   );
//    echo "<pre>";
// var_dump($order1);
$this->assign('list',$order1);
// $this->assign([
//             'name'  => 'ThinkPHP',
//             'email' => 'thinkphp@qq.com',
//             'title' => '这是一个标题！'
//         ]);
 return $this -> view -> fetch(); 
}

}