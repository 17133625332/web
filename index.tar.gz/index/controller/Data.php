<?php
namespace app\index\controller;
use think\Controller;
class Data extends Controller
{
  
    public function demo(){

    	$b = 'aaaaaa';


 		$aa = array 
		( 
	    "runoob"=>array 
	    ( 
	        "id"=>"菜鸟教程   ", 
	        "url"=>"http://www.runoob.com" 
	    ), 
	    "google"=>array 
	    ( 
	        "id"=>"Google搜索   ", 
	        "url"=>"http://www.google.com" 
	    ), 
	    "taobao"=>array 
	    ( 
	        "id"=>"淘宝   ", 
	        "url"=>"http://www.taobao.com" 
	    ), 
	    "baidu"=>array 
	    ( 
	        "id"=>"百度搜索    ", 
	        "url"=>"http://www.baidu.com" 
	    ), 
	    "360"=>array 
	    ( 
	        "id"=>"360搜索   ", 
	        "url"=>"http://www.360.com" 
	    ), 
	    "1"=>array 
	    ( 
	        "id"=>"淘宝   ", 
	        "url"=>"http://www.taobao.com" 
	    ), 
	    "2"=>array 
	    ( 
	        "id"=>"百度搜索    ", 
	        "url"=>"http://www.baidu.com" 
	    ), 
	    "3"=>array 
	    ( 
	        "id"=>"360搜索   ", 
	        "url"=>"http://www.360.com" 
	    )
		); 
	
	// var_dump($aa);
	$this->assign('list',$aa);
	$this->assign('list',$bb);	
    return $this -> view -> fetch();
    	
	}
}


