<?php
namespace app\index\controller;
use think\Controller;
class Demo extends Controller
{
  
    public function demo(){

    


 		$aa = array 
		( 
		    "0"=>array 
		    ( 
		        "id"=>1, 
		        "name"=>"5G全景采集直播工作室",
		        "content"=>"挺好用的1，挺好用的1挺好用的1挺好用的1挺好用的1挺好用的1挺好用的1挺好用的1挺好用的1挺好用的1挺好用的1",
		        "photo"=>array(
		        	'img1'=>"/static/img/pl1.jpg",
		        	'img2'=>"/static/img/pl2.jpg",
		        	'img3'=>"/static/img/pl3.jpg"
		        )
		    ), 
		    "1"=>array 
		    ( 
		        "id"=>2, 
		        "name"=>"从菜鸟工作室",
		        "content"=>"这里曾是我待过一点多的地方",
		        "photo"=>array(
		        	'img1'=>"__STATIC__/img/pl3.jpg",
		        	'img2'=>"__STATIC__/img/pl4.jpg",
		        	'img3'=>"__STATIC__/img/pl6.jpg"
		        )
		    ), 
		    "2"=>array 
		    ( 
		        "id"=>3, 
		        "name"=>"百度",
		        "content"=>"待遇挺好的!",
		        "photo"=>array(
		        	'img1'=>"__STATIC__/img/pl7.jpg",
		        	'img2'=>"__STATIC__/img/pl8.jpg",
		        	'img3'=>"__STATIC__/img/pl9.jpg"
		        )
		    ),
		); 

		$bb = array
		(
			"0"=> array(
				"id"=>1,
				"shop_name"=>"柜员蛋糕店",
				"shop_logo"=>"__STATIC__/img/logo.png"
			)
		);

		$cc = array
		(
			"0"=>array
			(
				"id" => 1,
				"class_name" => '慕斯稀奶油'
			),
			"1"=>array
			(
				"id" => 2,
				"class_name" => '儿童蛋糕'
			),
			"2"=>array
			(
				"id" => 3,
				"class_name" => '胚芽乳植脂奶油'
			),
			"3"=>array
			(
				"id" => 4,
				"class_name" => '稀奶油'
			)
		);

		$dd = array
		(
			"0" => array(
				"id" => 1,
				"good_name" => '仲夏夜之梦',
				"good_price" => 166,
				"good_content" => "酸酸甜甜的味道，吃一口哈哈笑，吃两口吓一跳，吃三口忘不掉",
				"good_url" => '__STATIC__/img/msc1.jpg',
				"good_num" => 10,
				'good_push' => 1,
				"class_id" => 1,
				"flag" => 1
			),
			"1" => array(
				"id" => 2,
				"good_name" => '洛林甜心',
				"good_price" => 166,
				"good_content" => "梦幻蛋糕，如梦随心所欲，如梦般环游世界！",
				"good_url" => '__STATIC__/img/msc2.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 1,
				"flag" => 0
			),
			"2" => array(
				"id" => 3,
				"good_name" => '香芒物语',
				"good_price" => 166,
				"good_content" => "不错，挺好吃的!",
				"good_url" => '__STATIC__/img/msc3.jpg',
				"good_num" => 10,
				'good_push' => 2,
				"class_id" => 1,
				"flag" => 1
			),
			"3" => array(
				"id" => 4,
				"good_name" => '鲜莓雪舞',
				"good_price" => 200,
				"good_content" => "哎呦，我去爱的味道！",
				"good_url" => '__STATIC__/img/msc4.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 1,
				"flag" => 0
			),
			"4" => array(
				"id" => 5,
				"good_name" => '香榭蜜语',
				"good_price" => 166,
				"good_content" => "哎呦不错呦！",
				"good_url" => '__STATIC__/img/x2.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 4,
				"flag" => 1
			),
			"5" => array(
				"id" => 6,
				"good_name" => '红丝绒圆舞曲',
				"good_price" => 166,
				"good_content" => "哎呦我去，挺好吃的!",
				"good_url" => '__STATIC__/img/x1.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 4,
				"flag" => 1
			),
			"6" => array(
				"id" => 7,
				"good_name" => '胚芽乳植脂奶油',
				"good_price" => 200,
				"good_content" => "哎呦，我去爱的味道！",
				"good_url" => '__STATIC__/img/pyr1.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 3,
				"flag" => 0
			),
			"7" => array(
				"id" => 8,
				"good_name" => '唯爱今生',
				"good_price" => 200,
				"good_content" => "哎呦，我去爱的味道！",
				"good_url" => '__STATIC__/img/pyr2.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 3,
				"flag" => 1
			),
		);
		$ee = array
		(
			"0" => array(
				"id" => 1,
				"good_name" => '仲夏夜之梦',
				"good_price" => 166,
				"good_url" => '__STATIC__/img/msc1.jpg',
				'good_push' => 1,
				"class_id" => 1,
				"flag" => 1
			),
			"1" => array(
				"id" => 2,
				"good_name" => '香芒物语',
				"good_price" => 166,
				"good_url" => '__STATIC__/img/msc3.jpg',
				'good_push' => 2,
				"class_id" => 1,
				"flag" => 1
			),
			"2" => array(
				"id" => 3,
				"good_name" => '香榭蜜语',
				"good_price" => 166,
				"good_url" => '__STATIC__/img/x2.jpg',
				'good_push' => 0,
				"class_id" => 4,
				"flag" => 1
			),
			"3" => array(
				"id" => 4,
				"good_name" => '红丝绒圆舞曲',
				"good_price" => 166,
				"good_url" => '__STATIC__/img/x1.jpg',
				'good_push' => 0,
				"class_id" => 4,
				"flag" => 1
			),
			"4" => array(
				"id" => 5,
				"good_name" => '唯爱今生',
				"good_price" => 200,
				"good_url" => '__STATIC__/img/pyr2.jpg',
				'good_push' => 0,
				"class_id" => 3,
				"flag" => 1
			),
		);

		$ff = array
		(
			"0" => array
			(
				"id" => 1,
				"yh_price" => 10,
				"yh_content" => "满100元可用"
			),
			"1" => array
			(
				"id" => 2,
				"yh_price" => 20,
				"yh_content" => "满150元可用"
			),
			"2" => array
			(
				"id" => 3,
				"yh_price" => 30,
				"yh_content" => "满200元可用"
			)
		);

		$gg = array
		(
			"0" => array
			(
				"goods_list" => array
				(
					"0" => array
					(
						'id' => 1,
						'name' => 'xiao'
					),
					"1" => array
					(
						'id' => 2,
						'name' => '1'
					)
				)
			)
		);
		// echo "<pre>";
		// var_dump($ff);
		// var_dump($aa);

		$this->assign('list',$ff);
	    return $this -> view -> fetch();
    	
	}

	public function goodDetail(){

		// $this->validate($data,['captcha|验证码'=>'require|captcha']);


		//接收输入商品的shop_id
		
		$choose_id = isset($_POST['good_id'])?$_POST['good_id']:$_GET['good_id'];
	
 		$goods_list = array
		(
			"0" => array
			(
				"good_id" => 1,
				"good_price" => 10,
				"good_name" => "意大利泡面"
			),
			"1" => array
			(
				"good_id" => 2,
				"good_price" => 20,
				"good_name" => "盼盼方式小面包"
			),
			"2" => array
			(
				"good_id" => 3,
				"good_price" => 30,
				"good_name" => "不是所有的奶都叫特仑苏"
			)
		);
		echo "<pre />";
		foreach ($goods_list as $key => $value) {
			if($choose_id == $value['good_id']){
				$good_detail = $value;
			}
			
		}
		var_dump($good_detail);
		$this->assign('list',$good_detail);
	    return $this -> view -> fetch();
	}



	public function upload(){
	    // 获取表单上传文件 例如上传了001.jpg
	    $file = request()->file('image');
	    // 移动到框架应用根目录/public/uploads/ 目录下
	    $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
   	    if($info){
          // 成功上传后 获取上传信息
          // 输出 jpg
          echo $info->getExtension();
          // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
          echo $info->getSaveName();
          // 输出 42a79759f284b767dfcb2a0197904287.jpg
          echo $info->getFilename(); 
	      }else{
          // 上传失败获取错误信息
           echo $file->getError();
   	   }	
	}




	public function hdjs(){
		$ff = array
		(
			"0" => array
			(
				"id" => 1,
				"yh_price" => 10,
				"yh_content" => "满100元可用"
			),
			"1" => array
			(
				"id" => 2,
				"yh_price" => 20,
				"yh_content" => "满150元可用"
			),
			"2" => array
			(
				"id" => 3,
				"yh_price" => 30,
				"yh_content" => "满200元可用"
			)
		);
		echo "<pre />";
		$ff = json_encode($ff);

		var_dump($ff);
		$this->assign('list',$ff);

	    return $this -> view -> fetch();
	}





	// Tp5中session的用法
	public function Sess(){
		//助手函数赋值
		session_start();
		session('username','thinkphp');
		echo "<pre >";
		var_dump($_SESSION);


	 	return $this -> view -> fetch();
	}


	//微信支付
	public function index(){
		


	} 




}


