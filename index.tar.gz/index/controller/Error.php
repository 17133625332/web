<?php

/*
*	空控制器的概念是指当系统找不到指定的控制器名称的时候，系统回尝试定位控制器Error利用这个机制我们可以用
*	来定制错误页面进行url的优化。
*	http://www.demo.com/index/city/shanghai
*	http://www.demo.com/index/shanghai
*	当找不到控制器的时候，就会找到Error控制器，
*
*/
namespace app\index\controller;
use think\Request;

class Error{



	public function index(Request $request){

		//根据当前控制器名来判断要执行那个城市的操作
		echo "<pre />";
	
		$cityName = $request -> controller();
		
		return $this -> city($cityName);
	}

	//注意city方法，本身是protected方法
	protected function city($name){
		//$name这个城市相关的处理
		return '当前城市'.$name;
	}
}

?>