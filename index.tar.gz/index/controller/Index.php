<?php
namespace app\index\controller;
use think\Controller;
class Index extends Controller
{
  
    public function index(){

    	

 		$aa = array 
		( 
	    "runoob"=>array 
	    ( 
	        "id"=>"菜鸟教程   ", 
	        "url"=>"http://www.runoob.com" 
	    ), 
	    "google"=>array 
	    ( 
	        "id"=>"Google搜索   ", 
	        "url"=>"http://www.google.com" 
	    ), 
	    "taobao"=>array 
	    ( 
	        "id"=>"淘宝   ", 
	        "url"=>"http://www.taobao.com" 
	    ), 
	    "baidu"=>array 
	    ( 
	        "id"=>"百度搜索    ", 
	        "url"=>"http://www.baidu.com" 
	    ), 
	    "360"=>array 
	    ( 
	        "id"=>"360搜索   ", 
	        "url"=>"http://www.360.com" 
	    ) 
		); 
	
	$aa = json_encode($aa);
	// var_dump($aa);
	$this->assign('list',$aa);
    return $this -> view -> fetch();
    	
	}
}


