<?php
namespace app\index\controller;
use think\Controller;
class Shoppingcart extends Controller
{
 public function shoppingcart(){
    $goods = array 
    ( 
        0=>array(  
            "shop_id"=>"0", 
            "shop_logo"=> "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=239786258,3895313333&fm=26&gp=0.jpg",            
            "shop_name"=>"佳佳装修门店",
            "goods_list"=>array(
                    array(
                        "goods_id" => "20190901101",
                        "goods_img" => "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3642160560,4265520888&fm=26&gp=0.jpg",
                        "goods_name" => "轻奢衣柜简约现代经济型组装北欧卧室实木柜子整体组合六门大衣橱",
                        "orderTransport" => "0",
                        "message" => "颜色分类：单功能柜；门数量:单门；是否组装:否",
                        "stock" => "5",
                        "price" => "10.03"
                    ),
                    array(
                        "goods_id" => "20190901102",
                        "goods_img" => "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3569799499,795906312&fm=26&gp=0.jpg",
                        "goods_name" => "轻奢简约现代门",
                        "orderTransport" => "0",
                        "message" => "颜色分类：五彩色；",
                        "stock" => "5",
                        "price" => "10.03"
                    ),
                    array(
                        "goods_id" => "20190901103",
                        "goods_img" => "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3569799499,795906312&fm=26&gp=0.jpg",
                        "goods_name" => "轻奢简约现代门",
                        "orderTransport" => "0",
                        "message" => "颜色分类：五彩色；",
                        "stock" => "5",
                        "price" => "10.03"
                    )
            )
        ),
        1 => array(
            "shop_id" => "4",
            "shop_logo" => "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=239786258,3895313333&fm=26&gp=0.jpg",
            "shop_name" => "佳佳装修门店",
            "goods_list"=>array(
                array(
                        "goods_id" => "20190901105",
                        "goods_img" => "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3114193000,2304595411&fm=26&gp=0.jpg",
                        "goods_name" => "欧式传统门",
                        "orderTransport" => "0",
                        "message" => "颜色分类：单功能柜；门数量:单门；是否组装:是",
                        "stock" => "1",
                        "price" => "520.00"
                )
            )
        ),
        2 => array(
            "shop_id" => "5",
            "shop_logo" => "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=239786258,3895313333&fm=26&gp=0.jpg",
            "shop_name" => "佳佳装修门店",
            "goods_list"=>array(
                array(
                        "goods_id" => "20190901106",
                        "goods_img" => "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1545958967,2524706599&fm=26&gp=0.jpg",
                        "goods_name" => "中式传统推拉门",
                        "orderTransport" => "0",
                        "message" => "颜色分类：按投影面积计价；投影数量:1平方米；购买方式:直接购买",
                        "stock" => "1",
                        "price" => "369.00"
                )
            )
        ),
        3 => array(
            "shop_id" => "6",
            "shop_logo" => "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=239786258,3895313333&fm=26&gp=0.jpg",
            "shop_name" => "佳佳装修门店",
            "goods_list"=>array(
                array(
                        "goods_id" => "20190901107",
                        "goods_img" => "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2801068810,742574753&fm=26&gp=0.jpg",
                        "goods_name" => "白色绣花衣柜",
                        "orderTransport" => "0",
                        "message" => "颜色分类：单功能柜；门数量:6门；是否组装:是",
                        "stock" => "1",
                        "price" => "560.00"
                )
            )
        ),
        4 => array(
            "shop_id" => "7",
            "shop_logo" => "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3067174750,3700750908&fm=26&gp=0.jpg",
            "shop_name" => "佳佳装修门店",
            "goods_list"=>array(
                array(
                        "goods_id" => "20190901108",
                        "goods_img" => "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2285205367,605145053&fm=26&gp=0.jpg",
                        "goods_name" => "格子色欧式门",
                        "orderTransport" => "0",
                        "message" => "颜色分类：棕色",
                        "stock" => "1",
                        "price" => "323.00"
                )
            )
        ),
        5 => array(
            "shop_id" => "8",
            "shop_logo" => "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3067174750,3700750908&fm=26&gp=0.jpg",
            "shop_name" => "佳佳装修门店",
            "goods_list"=>array(
                array(
                        "goods_id" => "20190901109",
                        "goods_img" => "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3569799499,795906312&fm=26&gp=0.jpg",
                        "goods_name" => "现代中式门",
                        "orderTransport" => "0",
                        "message" => "颜色分类：海棠色；门数量:4门；是否组装:整装",
                        "stock" => "100",
                        "price" => "105600.00"
                )
            )
        )

    );


    // echo "<pre>";
    // var_dump($shop);
    // var_dump($goods);
    
// ini_set("display_errors","On");
// error_reporting(E_ALL);
$this->assign('goods',$goods);
// $this->assign([
//             'name'  => 'ThinkPHP',
//             'email' => 'thinkphp@qq.com',
//             'title' => '这是一个标题！'
//         ]);
 return $this -> view -> fetch(); 
} }