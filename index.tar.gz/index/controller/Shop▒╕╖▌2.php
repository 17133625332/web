<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
header("content-type:text/html;charset=utf8");
class Shop extends Controller
{
  	


	public function demo(){

		

		

	 	//$result客户评论
	 	$result =  array 
		( 
		    "0"=>array 
		    ( 
		        "id"=>1, 
		        "name"=>"5G全景采集直播工作室",
		        "content"=>"新起点，新征程，加油！",
		        "photo"=>array(
		        	'img1'=>"/static/img/pl1.jpg",
		        	'img2'=>"/static/img/pl2.jpg",
		        	'img3'=>"/static/img/pl3.jpg"
		        )
		    ), 
		    "1"=>array 
		    ( 
		        "id"=>2, 
		        "name"=>"从菜鸟工作室",
		        "content"=>"这里曾是我待过一点多的地方",
		        "photo"=>array(
		        	'img1'=>"/static/img/pl3.jpg",
		        	'img2'=>"/static/img/pl4.jpg",
		        	'img3'=>"/static/img/pl6.jpg"
		        )
		    ), 
		    "2"=>array 
		    ( 
		        "id"=>3, 
		        "name"=>"百度",
		        "content"=>"待遇挺好的!",
		        "photo"=>array(
		        	'img1'=>"/static/img/pl7.jpg",
		        	'img2'=>"/static/img/pl8.jpg",
		        	'img3'=>"/static/img/pl9.jpg"
		        )
		    ),
		); 

		//$shop_message店铺信息
		$shop_message = array
		(
			
			"id"=>1,
			"shop_name"=>"柜员蛋糕店",
			"shop_logo"=>"__STATIC__/img/logo.png"
			
		);

		//$shop_class商品分类
		$shop_class = array
		(
			"0"=>array
			(
				"id" => 1,
				"class_name" => '慕斯稀奶油'
			),
			"1"=>array
			(
				"id" => 2,
				"class_name" => '儿童蛋糕'
			),
			"2"=>array
			(
				"id" => 3,
				"class_name" => '胚芽乳植脂奶油'
			),
			"3"=>array
			(
				"id" => 4,
				"class_name" => '稀奶油'
			)
		);

		//shop_goods商品信息
		$shop_goods = array
		(
			"0" => array(
				"id" => 1,
				"good_name" => '仲夏夜之梦',
				"good_price" => 166,
				"good_content" => "酸酸甜甜的味道，吃一口哈哈笑，吃两口吓一跳，吃三口忘不掉",
				"good_url" => '/static/img/msc1.jpg',
				"good_num" => 10,
				'good_push' => 1,
				"class_id" => 1,
				"flag" => 1
			),
			"1" => array(
				"id" => 2,
				"good_name" => '洛林甜心',
				"good_price" => 166,
				"good_content" => "梦幻蛋糕，如梦随心所欲，如梦般环游世界！",
				"good_url" => '/static/img/msc2.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 1,
				"flag" => 0
			),
			"2" => array(
				"id" => 3,
				"good_name" => '香芒物语',
				"good_price" => 166,
				"good_content" => "不错，挺好吃的!",
				"good_url" => '/static/img/msc3.jpg',
				"good_num" => 10,
				'good_push' => 2,
				"class_id" => 1,
				"flag" => 1
			),
			"3" => array(
				"id" => 4,
				"good_name" => '鲜莓雪舞',
				"good_price" => 200,
				"good_content" => "哎呦，我去爱的味道！",
				"good_url" => '/static/img/msc4.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 1,
				"flag" => 0
			),
			"4" => array(
				"id" => 5,
				"good_name" => '香榭蜜语',
				"good_price" => 166,
				"good_content" => "哎呦不错呦！",
				"good_url" => '__STATIC__/img/x2.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 4,
				"flag" => 1
			),
			"5" => array(
				"id" => 6,
				"good_name" => '红丝绒圆舞曲',
				"good_price" => 166,
				"good_content" => "哎呦我去，挺好吃的!",
				"good_url" => '/static/img/x1.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 4,
				"flag" => 1
			),
			"6" => array(
				"id" => 7,
				"good_name" => '胚芽乳植脂奶油',
				"good_price" => 200,
				"good_content" => "哎呦，我去爱的味道！",
				"good_url" => '__STATIC__/img/pyr1.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 3,
				"flag" => 0
			),
			"7" => array(
				"id" => 8,
				"good_name" => '唯爱今生',
				"good_price" => 200,
				"good_content" => "哎呦，我去爱的味道！",
				"good_url" => '__STATIC__/img/pyr2.jpg',
				"good_num" => 10,
				'good_push' => 0,
				"class_id" => 3,
				"flag" => 1
			),
		);

		//$rm_goods热卖商品
		$rm_goods = array
		(
			"0" => array(
				"id" => 1,
				"good_name" => '仲夏夜之梦',
				"good_price" => 166,
				"good_url" => '/static/img/msc1.jpg',
				'good_push' => 1,
				"class_id" => 1,
				"flag" => 1
			),
			"1" => array(
				"id" => 2,
				"good_name" => '香芒物语',
				"good_price" => 166,
				"good_url" => '/static/img/msc3.jpg',
				'good_push' => 2,
				"class_id" => 1,
				"flag" => 1
			),
			"2" => array(
				"id" => 3,
				"good_name" => '香榭蜜语',
				"good_price" => 166,
				"good_url" => '__STATIC__/img/x2.jpg',
				'good_push' => 0,
				"class_id" => 4,
				"flag" => 1
			),
			"3" => array(
				"id" => 4,
				"good_name" => '红丝绒圆舞曲',
				"good_price" => 166,
				"good_url" => '/static/img/x1.jpg',
				'good_push' => 0,
				"class_id" => 4,
				"flag" => 1
			),
			"4" => array(
				"id" => 5,
				"good_name" => '唯爱今生',
				"good_price" => 200,
				"good_url" => '__STATIC__/img/pyr2.jpg',
				'good_push' => 0,
				"class_id" => 3,
				"flag" => 1
			),
		);

		//$shop_yh优惠券
		$shop_yh = array
		(
			"0" => array
			(
				"id" => 1,
				"yh_price" => 15,
				"yh_content" => "满100元可用"
			),
			"1" => array
			(
				"id" => 2,
				"yh_price" => 20,
				"yh_content" => "满150元可用"
			),
			"2" => array
			(
				"id" => 3,
				"yh_price" => 30,
				"yh_content" => "满200元可用"
			)
		);
		//方法二：
	 	// echo "<pre />";	
	 	// var_dump($result);
	 	// var_dump($shop_message);
	 	// var_dump($shop_class);
	 	// var_dump($shop_goods);
	 	// var_dump($rm_goods);
	 	// var_dump($shop_yh);

		$view = $this->view;
		$view ->list = $result;
		$view ->shop = $shop_message;
		$view ->class= $shop_class;
		$view ->goods= $shop_goods;
		$view ->rm= $rm_goods;

		$view ->yh = $shop_yh;
		
	    return $this -> view -> fetch();
    	
	}


}
?>

