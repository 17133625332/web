<?php
namespace app\index\controller;
use think\View;
use think\Controller;

class Test extends Controller{
	public function _initialize(){
		echo "init<br />";
	}

	public function hello(){
		return "hello";
	}

	public function data(){
		return 222;
		// return ['name'=>'thinkphp','status'=>1];
	}

	public function index(){
		//通过return的方法只能显示控制器种的内容
		//但是通过view的方法可以显示html种的内容

		//reutrn方法直接阻止下面的程序运行
		return 111111;
		

		//显示页面中的内容
		$view = new View();
		return $view->fetch("index");
	}


	public function index1(){
		//显示index.html模板
		return view('index');
	}

	public function index2(){
		//获得包含域名的完整的URL地址
		$a = $_GET['a'];
		
		echo $a;
		echo "<br />";
		$this -> assign("domain",$this->request->url(true));
		return $this -> fetch("index");
	}


	//渲染输出
	public function  json(){
		$data = ['name'=>'thinkphp','status'=>1];
		return json_encode($data);
	}

	public function read(){
		return view();
	}


	/*
	*	前置操作
	*
	*/

	protected $beforeActionList = [
		'first',
		"second" => ['except' => "he"],
		"three" => ["only" => 'he,data1'],
	];

	protected function first(){
		echo "first<br />";
	}

	protected function second(){
		echo "second<br />";
	}

	protected function three(){
		echo "three<br />";
	}

	public function he(){
		return "he";
	}

	public function data1(){
		return "data";
	}


	/*
	*	跳转和重定向   think\Controller类内置的两个跳转方法success和error用于页面跳转
	*
	*/

	public function jump(){
		$flag = 1;

		if($flag == 1){
			//重定向
			$this->redirect('test/data1',302);


			//执行成功 
			//设置成功后跳转页面的地址，默认的返回页面是$_SERVER['HTTP_REFERE']
			$this -> success('新增成功','test/data1');
		}else{
			//执行失败
			//执行失败默认跳转页面是返回前一页，通常不设置。
			$this -> error("执行失败");
		}
	}



	/*
	*	空操作   
	*	用户在找不到指定的操作方法时，会定位到空操作(empty)方法执行时，利用这个机制，我们可以实现错误页面和url的优化
	*
	*/

	public function _empty($name){
		//包所有城市的操作方法解析到city方法
		return $this->showCity($name);
	}

	//注意showCity方法，本身是protected方法
	protected function showCity($name){
		//和$name这个城市相关的处理
		return '当前城市'.$name;
	}



	/*
	*
	*	空控制器该案例的实现在Error.php中
	*
	*/



	/*
	*
	*	多级控制器在one/Blog.php中
	*
	*/



	/*
	*
	*	分层控制器
	*	Thinkphp引入了分层控制器的概念，，通过url访问的控制层(Controller)或者主控制层，访问控制器是由、think\App类扶着调用和实例化的，无需手动实例化
	*
	*/

	public function index4(){
		return 'index4';
	}

	public function add(){
		return 'add';
	}

	public function edit2($id){
		//tp5传递参数可以通过url方式进行。以下两种方式同时进行。
		//http://www.demo.com/index/test/edit2/id/2   id=2
		//http://www.demo.com/index/test/edit2?id=3   id=3
		return 'edit:'.$id;
	}

	//分层控制器
	public function insert(){
		return "insert";
	}

	public function update($id){
		// return view();
		return "update:".$id;
	}

	public function delete($id){
		// return view();
		return 'delete:'.$id;
	}

	public function test(){
		//可以通过这种方式访问其它控制器中的方法。
		/*
		//定义完成后，就可以使用下面的方式实例化并调用方法了
		$event = \think\Loader::controller("Test",'controller');
		echo $event->update(3);
		echo $event->delete(2);
		*/

		//为了方便调用，系统提供了controller助手函数直接实例化多层控制器，例如：
		/*
		$event = controller("test","controller");
		echo $event->update(5);
		echo $event->delete(5);
		*/

		//支持跨域块调用  及跨越不同的模板
		/*
		*
		*/
		/*
		$event = controller("Admin/Blog",'controller');
		echo $event->update(5);
		*/

		//除了分层控制器外，也可以调用分层控制器类的某个方法，例如：
		echo \think\Loader::action("Test/update",['id' => 5],'event');
		echo \think\Loader::action('Test/update', ['id' => 5], 'event'); // 输出 update:5
		echo action('Test/update', ['id' => 5], 'event'); // 输出 update:5



		/*自定位控制器
		*
		*	如果使用了舵机控制器的话，可以使用controller_auto_search参数开启自动定位控制器
		*	便于访问url，首先在配置文件中添加
		*	one/Blog.php
		*
		*	1.可以使用http://www.demo.com/index/one.blog/index访问
		*	2.可以在config.php中添加"controller_auto_search=>true";然后通过http://www.demo.com/index/one/Blog/index自动搜素
		*/


	}


}



?>