<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
//use app\weibo\model\User as UserModel; 
class Weibo extends Controller
{
  public function index(){
 	if(action('isLogin')){
      $this->redirect('/index/weibo/home');
    }
  	return view();
  }

 /*		*	*	*	*	*
 *
 *	个人主页
 *
 *		*	*	*	*	*/
  public function home(){
   	if(!action('isLogin')){
      $this->redirect('/index/weibo/index');
    }
    //取出自己发的和粉主推过来的信息
    $r = action('connredis');
    $r->ltrim('recivepost:'.$_COOKIE['userid'],0,49);
    //修改前的方式
    //$newposter = $r->sort('recivepost:'.$_COOKIE['userid'],array('sort'=>'desc','get'=>'post:postid:*:content'));
  	//修改后数据类型为hash
    $newposter = $r->sort('recivepost:'.$_COOKIE['userid'],array('sort'=>'desc'));
   
    
    
    
    $message = [];
    foreach($newposter as $postid){
    	$message[] = $r->hmget('post:postid:'.$postid,array('userid','username','content','time'));
      	//$message['time'] = action('formattime',$message[$postid-1]['time']);
    }
   
    foreach($message as $k => $v){
      $message[$k]['time'] = action('formattime',$v['time']);
    }
   
    
    //获取几个粉丝，几个关注
    //计算集合的元素个数
    $myfans = $r->sCard('follower:'.$_COOKIE['username']);
    $mystars = $r->sCard('following:'.$_COOKIE['userid']);
    
    
    $view = $this->view;
    //我的粉丝
    $view -> myfans = $myfans;
    $view -> mystars = $mystars;
	$view ->message = $message;
    return $this -> view -> fetch();
  
  }
  
  /*	*	*	*	*	*
  *	格式化时间戳
  *
  *		*	*	*	*	*/
  function formattime($time){
  	$sec = time() -$time;
    if($sec >= 86400){
    	return floor($sec/86400).'天';
    }else if($sec >= 3600){
    	return floor($sec/3600).'小时';
    }else if($sec >= 60){
    	return floor($sec/60).'分钟';
    }else{
    	return $sec.'秒';
    }
  }
 
  
  
  
  
  /*	*	*	*	*	*
  *
  *		个人主页详情
  *
  *		*	*	*	*	*/

  public function profile(){
    //1.防止非法访问
    if(!action('isLogin')){
      $this->redirect('/index/weibo/index');
    }else{
      $r = action('connredis');
      
      $u = $_GET['username'];
     
      $prouid = $r->get('user:username:'.$u.':userid');
       
      if(!$prouid){
      	action('err','非法用户');
      }
      
      $isf = $r->sismember('following:'.$_COOKIE['userid'],$u);
      
      $isfstatus = $isf?'1':'0';
      $isfword = $isf?'取消关注':'关注ta';
    }
    echo "<br />";
    echo $isfword;
    
    $view = $this->view;
	$view ->isfword = $isfword;
    $view->proname = $u;
    return $this -> view -> fetch();
  	
  }
  
  /*	*	*	*	*	*
  *
  *
  *	发布文章
  *
  *
  *		*	*	*	*	*/
  public function post(){
  	//1.防止非法访问
    if(!action('isLogin')){
      $this->redirect('/index/weibo/index');
    }else{
      //2.接收文章的信息
      $con = isset($_POST['content'])?$_POST['content']:"Hello World!";
      if(!$con){
      	action('err','请填写内容');
        $this->redirect('/index/weibo/home');
      }else{
     	//3.向数据库中添加内容
    	$r = action('connredis');
        $postid = $r->incr('global:postid');
        /*
        $r->set('post:postid:'.$postid.'userid',$_COOKIE['userid']);
        $r->set('post:postid:'.$postid.':time',time());
        $r->set('post:postid:'.$postid.':content',$con);
        */
       
        //改正后-->将time以及content以及用户名都存放到hash列表中方便操作。
        $r->hmset('post:postid:'.$postid,array('userid'=>$_COOKIE['userid'],'username'=>$_COOKIE['username'],'time'=>time(),'content'=>$con));
        //把微博推荐给自己的粉丝
        $fans = $r->smembers('follower:'.$_COOKIE['username']);
      
        //将微博给自己一份
        $fans[] = $_COOKIE['userid'];
        
        foreach($fans as $fansid){
          	//将微博存放到粉丝能够看到的列表中
        	$r->lpush('recivepost:'.$fansid,$postid);
        }
     
        $this->redirect('/index/weibo/home');
     } 

    }
    
    
  }

  //热点
  /*	*	*	*	*	*
  *	1.显示最新注册的用户
  *	2.显示最近50条博文
  *		*	*	*	*	*/
  public function timeline(){
    //1.防止非法访问
    if(!action('isLogin')){
      $this->redirect('/index/weibo/index');
    }else{
      $r = action('connredis');
      $newuserlist = array();
      $newuserlist = $r->sort('newuserlink',array('sore'=>'desc','get'=>'user:userid:*:username'));
     
      $view = $this->view;
	  $view ->newuser = $newuserlist;
    }
    return $this -> view -> fetch();
    
  
  }

  
  
  
  //用户注册验证
  public function register(){
  	//dump($_POST);
  	$a = isset($_POST['re_username'])?$_POST['re_username']:"root";
  	$p = isset($_POST['re_password'])?$_POST['re_password']:"123456";
	$p1 = isset($_POST['re_repassword'])?$_POST['re_repassword']:"123456";
  	$username = action('p',"$a");
  	$password = action('p',"$p");
  	$password2 = action('p',"$p1");
  	if(!$username || !$password || !$password2){
  		action('err',"请输入完整信息!!!");
  	}else{
  		//判断密码是否一致
  		if($password == $password2){
  			echo "密码相同";
  		}else{
  			action('err',"两次密码不相同!!!");
  		}
  	}

  	//连接redis
  	$r = action('connredis');
    
  	//查询用户名是否已被注册
   
  	if(($r->get('user:username:'.$username.':userid'))){
    	action('err','用户名已被注册请更换');
        $this->redirect('/index/weibo/index');
    }else{
    	//用户名可以正常使用
      	//使得user_id自增
      	$userid = $r->incr('global:userid');
      	$r->set('user:userid:'.$userid.':username',$username);
      	$r->set('user:userid:'.$userid.':password',$password);
      	$r->set('user:username:'.$username.':userid',$userid);
      	
      	//通过一个链接，维护50个最新的userid
      	$r->lpush('newuserlink',$userid);
      	$r->ltrim('newuserlink',0,49);
     	$this->redirect('/index/weibo/index');
    }
  
  	
  }


  /*	*	*	*	*	*	
  *
  *	用户登录
  *
  *		*	*	*	*	*/
 
  public function login(){
    dump($_POST);
    $username = isset($_POST['lo_username'])?$_POST['lo_username']:"root";
  	$password = isset($_POST['lo_password'])?$_POST['lo_password']:"123456";
    
	if(!$username || !$password){
    	action('err','请输入完整信息!');
    }else{
      
      	$r = action('connredis');
        $userid = $r->get('user:username:'.$username.':userid');
      	//判断用户id是否存在
      	if(!$userid){
        	action('err','用户名不存在');
          
        	$this->redirect('/index/weibo/index');
        }else{
        	//查看密码是否匹配
          	$realpass = $r->get('user:userid:'.$userid.':password');
          	if($password != $realpass){
            	action('err','密码不对');
            }else{
            	//echo "密码正确";
              	setcookie('username',$username);
              	setcookie('userid',$userid);
              	
              //设置cookie加密，防止篡改cookie的值 .然后将生成的随机数放到redis服务器中进行验证
              	$authsecret = action('randsecret');
              	setcookie('authsecret',$authsecret);
              	$r->set('user:userid:'.$userid.':authsecret',$authsecret);
              
           		$this->redirect('/index/weibo/home');
            }
        }
    }
  }
  
  /*	*	*	*	*	*
  *
  *	随机产生16位的字符串
  *
  *
  *		*	*	*	*	*/
  function randsecret(){
  	$str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*~<>()';
    return substr(str_shuffle($str),0,16);
  }
  
  
  
  /*	*	*	*	*	*
  *
  *用户退出登陆
  *
  */
  
  public function logout(){
    if(!action('isLogin')){
      $this->redirect('/index/weibo/index');
    }
    $r = action('connredis');
    $r->set('user:userid:'.$_COOKIE['userid'].':authsecret','');
  	setcookie('username','',-1);
    setcookie('userid','',-1);
    setcookie('authsecret','',-1);
   
    $this->redirect('/index/weibo/index');
  }
  
  

  //基础函数库
  public function p($key){
  	return $key;
  	// return $_POST[$key];
  }
	
  public function g($key){
  	return $_POST[$key];
  }

  //报错函数
  public function err($msg){
    echo "<br/>";
  	echo $msg;
  	
  }

  
  /*	*	*	*	*	*	
  *
  *		链接redis
  *
  *		*	*	*	*	*/
  function connredis(){
  
  	$redis = new \Redis();
  	//2.connect to redis server连接redis服务器
  	$redis->connect('129.211.54.147');
  	return $redis;
  }
  
  /*	*	*	*	*	*	
  *
  *		判断用户是否登陆成功
  *
  *		*	*	*	*	*/
	function isLogin(){
      if(!isset($_COOKIE['userid']) || !isset($_COOKIE['username']) || !isset($_COOKIE['authsecret']) ){
      	return false;
      }else{
        $r = action('connredis');
       
        $authsecret = $r->get('user:userid:'.$_COOKIE['userid'].':authsecret');
        $username = $r->get('user:userid:'.$_COOKIE['userid'].':username');
       
        if($authsecret != $_COOKIE['authsecret'] || $username != $_COOKIE['username'] ){
        	return false;
        }else{
          return array(
          			'userid'=>$_COOKIE['userid'],
         			'username'=>$_COOKIE['username']
          			);       
        } 	
      }
    }
  
  
  /*	*	*	*	*	*	
  * 
  *
  *		关注和取消关注
  *
  *		*	*	*	*	*/
  function follow(){
    
  	 if(!action('isLogin')){
      $this->redirect('/index/weibo/index');
    }else{
       $r = action('connredis');
       //1.判断uid，f是否是合法值
       //2.判断uid是否是自己
       $uid = $_GET['username'];
       
       $f = $r->sismember('following:'.$_COOKIE['userid'],$uid)?0:1;
       
      
     	
     
       if($f ==1){
         
       		$r->sadd('following:'.$_COOKIE['userid'],$uid);
      	 	$r->sadd('follower:'.$uid,$_COOKIE['userid']);
        
         
       }else{
       		$r->srem('following:'.$_COOKIE['userid'],$uid);
            $r->srem('follower:'.$uid,$_COOKIE['userid']);
      
         
       }
     
       $uname = $r->get('user:userid:'.$uid.':username');
    	
       $this->redirect("http://www.lz-family.cn/WWW/demo/public/index/weibo/profile.html?username=$uid");
      
    }
      //$view = $this->view;
	  //$view ->newuser = $newuserlist;
      //return $this -> view -> fetch();
     
    
  }
 
  
}


