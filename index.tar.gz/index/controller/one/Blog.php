<?php
namespace app\index\controller\one;
use think\Controller;

class Blog extends Controller{
	public function index(){
		echo 111111;
		return $this->fetch();
	}

	public function add(){
		return $this->fetch();
	}

	public function edit(){
		return $this->fetch();
	}
}


?>