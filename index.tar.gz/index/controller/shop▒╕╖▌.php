<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use app\index\model\Shop as ShopModel;
use app\index\model\User as UserModel;
use app\index\model\Goods as GoodsModel;
use app\index\model\Yh as YhModel;
use app\index\model\Shop_message as UserMessageModel;
use app\index\model\Shop_class as UserClassModel;
header("content-type:text/html;charset=utf8");
class Shop extends Controller
{
  	


	public function demo(){

		$result = Db::table('shop')->select();
		
		foreach ($result as $key => $value) {
			// echo "<pre />";
			// var_dump(unserialize($value['photo']));
			// var_dump(unserialize($result[$key]['photo']));
			//注意这两种方式，结果一样但是下面会报错
			$result[$key]['photo'] = unserialize($result[$key]['photo']);
			// $value['photo'] = unserialize($value['photo']);
		}
	
		// $result[2]['photo'] = unserialize($result[2]['photo']);
	
		//shop_message用于显示商店名称以及商店logo
		$shop_message = Db::table('shop_message')->select()[0];
		$shop_message = $shop_message;
		
		//查询分类
		$shop_class = Db::table('shop_class')->select();

		//查询商品
		$shop_goods = Db::table('goods')->select();
		
		
		//查询优惠信息
		$shop_yh = Db::table('yh')->select();

		//查询热卖信息
		$rm_goods = Db::table('goods')->where('flag',1)->select();

		
		$arr = [
	 	'img1' => '/static/img/qbsp1.jpg',
	 	'img2' => '/static/img/qbsp1.jpg',
	 	'img3' => '/static/img/qbsp1.jpg'
	 	 ];

	 	 $arr = serialize($arr);
	 	
		//方法一：通过assign方法
		//$this->assign('list',$result);

		//方法二：
	 	// echo "<pre />";	
	 	// var_dump($result);
	 	// var_dump($shop_message);
	 	// var_dump($shop_class);
	 	// var_dump($shop_goods);

		$view = $this->view;
		$view ->list = $result;
		$view ->shop = $shop_message;
		$view ->class= $shop_class;
		$view ->goods= $shop_goods;
		$view ->rm= $rm_goods;

		$view ->yh = $shop_yh;
		
	    return $this -> view -> fetch();
    	
	}



	public function index(){
		echo 11111;
		$arr = [
		 	'db_host' => 'localhost',
		 	'db_user' => 'root',
		 	'db_pass' => 'root',
		 	'db_name' => 'test'];
 		echo "<pre />";
 	
		$arr = [
	 	'img1' => '/static/img/qbsp1.jpg',
	 	'img2' => '/static/img/qbsp1.jpg',
	 	'img3' => '/static/img/qbsp1.jpg'
	 	 ];

	 	 $arr = serialize($arr);

		 
var_dump($arr);
		$arr = [
	 	'img1' => '/static/img/ql1.jpg',
	 	'img2' => '/static/img/ql2.jpg',
	 	'img3' => '/static/img/ql3.jpg'
	 	 ];

	 	 $arr = serialize($arr);

		 
var_dump($arr);
		 // echo "<pre>";
		 $re = Db::table('goods')->select();
		 
		// var_dump($re[0]['good_name']);
		$re[0]['good_name'] = $arr;
		$re[1]['good_name'] = $arr;
		$re[2]['good_name'] = $arr;
		$re[3]['good_name'] = $arr;
		// var_dump($re);

		
		 $view = $this->view;
		 $view->data=$arr;
		 $view->list=$re;
		
		 return $this -> view -> fetch();


	}



}
?>

