
array(4) {
  [0]=>
  array(8) {
    ["id"]=>
    int(1)
    ["good_name"]=>
    string(12) "草莓蛋糕"
    ["good_price"]=>
    int(150)
    ["good_content"]=>
    string(84) "酸酸甜甜的味道，吃一口哈哈笑，吃两口吓一跳，吃三口忘不掉"
    ["good_url"]=>
    string(21) "/static/img/qbsp1.jpg"
    ["good_num"]=>
    int(10)
    ["good_push"]=>
    int(1)
    ["class_id"]=>
    int(1)
  }
  [1]=>
  array(8) {
    ["id"]=>
    int(2)
    ["good_name"]=>
    string(12) "梦幻蛋糕"
    ["good_price"]=>
    int(300)
    ["good_content"]=>
    string(57) "梦幻蛋糕，如梦随心所欲，如梦般环游世界"
    ["good_url"]=>
    string(21) "/static/img/qbsp1.jpg"
    ["good_num"]=>
    int(10)
    ["good_push"]=>
    int(0)
    ["class_id"]=>
    int(1)
  }
  [2]=>
  array(8) {
    ["id"]=>
    int(3)
    ["good_name"]=>
    string(12) "香蕉蛋糕"
    ["good_price"]=>
    int(200)
    ["good_content"]=>
    string(21) "不错，挺好吃的"
    ["good_url"]=>
    string(21) "/static/img/qbsp1.jpg"
    ["good_num"]=>
    int(10)
    ["good_push"]=>
    int(2)
    ["class_id"]=>
    int(1)
  }
  [3]=>
  array(8) {
    ["id"]=>
    int(4)
    ["good_name"]=>
    string(12) "奶油蛋糕"
    ["good_price"]=>
    int(200)
    ["good_content"]=>
    string(27) "哎呦，我去爱的味道"
    ["good_url"]=>
    string(21) "/static/img/qbsp1.jpg"
    ["good_num"]=>
    int(280)
    ["good_push"]=>
    int(0)
    ["class_id"]=>
    int(1)
  }
}